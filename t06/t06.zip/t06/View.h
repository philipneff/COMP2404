#ifndef VIEW_H
#define VIEW_H

#include <string>
using namespace std;

class View
{
  public:
    View();
    int mainMenu();
    string bookInput();
    void print();
};

#endif




